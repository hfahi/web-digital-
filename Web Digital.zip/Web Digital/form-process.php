 <?php
  if(isset($_POST)&& !empty($_POST['nom'])&& !empty($_POST['sujet'])&& !empty($_POST['message'])){
   extract($_POST);
   $destinataire='hamza.fahi@gmail.com'; // Adresse email destinataire
   $expediteur=$nom.' <'.$email.'>';
   $mail=mail($destinataire,$sujet,$message,$expediteur.' : Web Digital : Formulaire de contact');
   if($mail) echo 'Email envoyé avec succés vous aurez un retour dans quelques minutes par mail merci';
   else echo'Echec envoi ';
  }else echo"Formulaire non soumis ou des champs vides";
 ?>